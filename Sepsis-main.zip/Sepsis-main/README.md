Features:
('admission_type', 'ethnicity', 'sbp','respiratory_rate', 
'heart_rate', 'spo2', 'wbc', 'lactate',sbp_heart_rate ,wbc_lactate)
